#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <signal.h>
#include <stdbool.h>
#include <sys/time.h>
#include <time.h>
#include <sys/file.h>

void write_log(const char *message) {
//open without resetting the file
    FILE *log = fopen("log/logfile.txt", "a"); 
    if (!log) {
        perror("fopen");
        return;
    }
//lock
    int fd = fileno(log);
    if (flock(fd, LOCK_EX) != 0) { // wait for the file to be available
        perror("flock");
        fclose(log);
        return;
    }

// write
    // Create a time tag
    struct timeval tv;
    gettimeofday(&tv, NULL); //read seconds and microseconds
    struct tm* tm_info = localtime(&tv.tv_sec);//change seconds into hour/minut/second
    int millis = tv.tv_usec / 1000;//change microseconds into milliseconds
    //Create a string with all the numbers
    static char buffer[32];
    snprintf(buffer, sizeof(buffer),"%02d:%02d:%02d.%03d",tm_info->tm_hour,tm_info->tm_min,tm_info->tm_sec,millis);

    fprintf(log, "[%s] [W] %s\n", buffer, message);
//flush
    fflush(log);
// unlock
    flock(fd, LOCK_UN);
//close the file
    fclose(log);
}

//Signal handler
volatile sig_atomic_t running = 1;
void handler(int s) {
    running = 0;
}
//function to print time of day
char * timeOfDay() {
    struct timeval tv;
    gettimeofday(&tv, NULL); //read seconds and microseconds
    struct tm* tm_info = localtime(&tv.tv_sec);//change seconds into hour/minut/second
    int millis = tv.tv_usec / 1000;//change microseconds into milliseconds
    //Create a string with all the numbers
    static char buffer[32];
    snprintf(buffer, sizeof(buffer),"%02d:%02d:%02d.%03d",tm_info->tm_hour,tm_info->tm_min,tm_info->tm_sec,millis);
    return buffer;
}

int main(){
    write_log("[INFO] Starting");
//Setup the time variables
    time_t now;
    time_t last_answer[5];
    time_t const deadline = 2; //seconds
    bool alerte[5];

    now=time(NULL);
    for(int i =0;i<5;i++){
        last_answer[i]=time(NULL);
        alerte[i]=false;
    }
//Open a file to printf the messages
    FILE *fp = fopen("log/watchdog.txt", "w"); //Replace the past values
    if (fp == NULL) {
        write_log("[ERROR] Can't open the watchdog file");
        perror("watchdog.txt not open");
        return EXIT_FAILURE;
    }
    setvbuf(fp, NULL, _IONBF, 0); //no buffer to write in the file, so no missing information in case of crash
    fprintf(fp, "[%s] [Watchdog] Starting\n",timeOfDay());
    write_log("[INFO] Opening file to print the messages");
//Signal setup
    signal(SIGTERM, handler);
    //must block the other signals if the program is launched in konsole
    signal(SIGINT, handler);
    signal(SIGTERM, handler);
    signal(SIGHUP, handler);
// -----OPENNING THE PIPES-------------------------------------
    char * fifoBtoW = "/tmp/fifoBtoW"; 
    char * fifoDtoW = "/tmp/fifoDtoW"; 
    char * fifoItoW = "/tmp/fifoItoW"; 
    char * fifoOtoW = "/tmp/fifoOtoW"; 
    char * fifoTtoW = "/tmp/fifoTtoW"; 
    
    int fdB  = open(fifoBtoW, O_RDONLY);
    int fdD  = open(fifoDtoW, O_RDONLY);
    int fdI  = open(fifoItoW, O_RDONLY);
    int fdO  = open(fifoOtoW, O_RDONLY);
    int fdT  = open(fifoTtoW, O_RDONLY);

    if (fdB < 0 || fdD < 0 || fdI < 0 || fdO < 0 || fdT < 0) {
        write_log("[ERROR] Can't open the pipes");
        perror("open fifo");
        exit(1);
    }
//-----Main loop----------
    write_log("[INFO] Starting to watch");
    while(running){
    //create the select()
        fd_set rset;
        FD_ZERO(&rset);
        FD_SET(fdB, &rset);
        FD_SET(fdD, &rset);
        FD_SET(fdI, &rset);
        FD_SET(fdO, &rset);
        FD_SET(fdT, &rset);

        int maxfd = fdB;
        if(fdD>maxfd) maxfd=fdD;
        if(fdI>maxfd) maxfd=fdI;
        if(fdO>maxfd) maxfd=fdO;
        if(fdT>maxfd) maxfd=fdT;

        select(maxfd + 1, &rset, NULL, NULL, NULL);

    // if B is talking
        if (FD_ISSET(fdB, &rset)) {
            //read the message
            char buf[128];
            if (read(fdB, buf, sizeof(buf)) > 0) {
                printf("[B] %s",buf);
                fprintf(fp, "[%s] [B] %s",timeOfDay(),buf);
                last_answer[0]=time(NULL);
                alerte[0]=false;
            }
        }
    // if D is talking
        if (FD_ISSET(fdD, &rset)) {
            //read the message
            char buf[128];
            if (read(fdD, buf, sizeof(buf)) > 0) {
                printf("[D] %s",buf);
                fprintf(fp, "[%s] [D] %s",timeOfDay(),buf);
                last_answer[1]=time(NULL);
                alerte[1]=false;
            }
        }
    // if I is talking
        if (FD_ISSET(fdI, &rset)) {
            //read the message
            char buf[128];
            if (read(fdI, buf, sizeof(buf)) > 0) {
                printf("[I] %s",buf);
                fprintf(fp, "[%s] [I] %s",timeOfDay(),buf);
                last_answer[2]=time(NULL);
                alerte[2]=false;
            }
        }
    // if O is talking
        if (FD_ISSET(fdO, &rset)) {
            //read the message
            char buf[128];
            if (read(fdO, buf, sizeof(buf)) > 0) {
                printf("[O] %s",buf);
                fprintf(fp, "[%s] [O] %s",timeOfDay(),buf);
                last_answer[3]=time(NULL);
                alerte[3]=false;
            }
        }
    // if T is talking
        if (FD_ISSET(fdT, &rset)) {
            //read the message
            char buf[128];
            if (read(fdT, buf, sizeof(buf)) > 0) {
                printf("[T] %s",buf);
                fprintf(fp, "[%s] [T] %s",timeOfDay(),buf);
                last_answer[4]=time(NULL);
                alerte[4]=false;
            }
        }
    // check if some processes didn't answer
        now = time(NULL);
        if(((now-last_answer[0])>deadline)&&(alerte[0]==false)) {
            printf("ALERTE : B IS NOT TALKING\n");
            write_log("[WARN] Detecting B has stopped");
            fprintf(fp, "[%s] [B] ALERTE : B IS NOT TALKING\n",timeOfDay());
            alerte[0]=true;
        }
        if(((now-last_answer[1])>deadline)&&(alerte[1]==false)) {
            printf("ALERTE : D IS NOT TALKING\n");
            write_log("[WARN] Detecting D has stopped");
            fprintf(fp, "[%s] [D] ALERTE : D IS NOT TALKING\n",timeOfDay());
            alerte[1]=true;
        }
        if(((now-last_answer[2])>deadline)&&(alerte[2]==false)) {
            printf("ALERTE : I IS NOT TALKING\n");
            write_log("[WARN] Detecting I has stopped");
            fprintf(fp, "[%s] [I] ALERTE : I IS NOT TALKING\n",timeOfDay());
            alerte[2]=true;
        }
        if(((now-last_answer[3])>deadline)&&(alerte[3]==false)) {
            printf("ALERTE : O IS NOT TALKING\n");
            write_log("[WARN] Detecting O has stopped");
            fprintf(fp, "[%s] [O] ALERTE : O IS NOT TALKING\n",timeOfDay());
            alerte[3]=true;
        }
        if(((now-last_answer[4])>deadline)&&(alerte[4]==false)) {
            printf("ALERTE : T IS NOT TALKING\n");
            write_log("[WARN] Detecting T has stopped");
            fprintf(fp, "[%s] [T] ALERTE : T IS NOT TALKING\n",timeOfDay());
            alerte[4]=true;
        }
    }
//Terminate program
    write_log("[INFO] Terminating");
    //Close the file
    if (fclose(fp) != 0) {
        perror("watchdog.txt not closed");
        write_log("[ERROR] Can't close the watchdog file");
        return EXIT_FAILURE;
    }
    close(fdB); 
    close(fdD);
    close(fdI);
    close(fdO);
    close(fdT); 
    return 0;
}