#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <signal.h>
#include <pthread.h>
#include <time.h>
#include <sys/time.h>
#include <sys/file.h>

void write_log(const char *message) {
//open without resetting the file
    FILE *log = fopen("log/logfile.txt", "a"); 
    if (!log) {
        perror("fopen");
        return;
    }
//lock
    int fd = fileno(log);
    if (flock(fd, LOCK_EX) != 0) { // wait for the file to be available
        perror("flock");
        fclose(log);
        return;
    }

// write
    // Create a time tag
    struct timeval tv;
    gettimeofday(&tv, NULL); //read seconds and microseconds
    struct tm* tm_info = localtime(&tv.tv_sec);//change seconds into hour/minut/second
    int millis = tv.tv_usec / 1000;//change microseconds into milliseconds
    //Create a string with all the numbers
    static char buffer[32];
    snprintf(buffer, sizeof(buffer),"%02d:%02d:%02d.%03d",tm_info->tm_hour,tm_info->tm_min,tm_info->tm_sec,millis);

    fprintf(log, "[%s] [T] %s\n", buffer, message);
//flush
    fflush(log);
// unlock
    flock(fd, LOCK_UN);
//close the file
    fclose(log);
}

//function to generate random number in a certain range
int random_int(int min, int max) {
    // read the random number form the faile /dev/urandom
    int fd = open("/dev/urandom", O_RDONLY);
    if (fd < 0) {
        perror("open");
        return -1;
    }
    int rand_val;
    if (read(fd, &rand_val, sizeof(rand_val)) != sizeof(rand_val)) {
        perror("read");
        close(fd);
        return -1;
    }
    close(fd);
    //only positive numbers
    int pos_val;
    if(rand_val<0)
        pos_val=-rand_val;
    else
        pos_val=rand_val;
    // re-size in the intervale [min, max]
    return min + (pos_val % (max - min + 1));
}
//Signal handler
int running = 1;
void handler(int s) {
    running = 0;
}
//Thread for sending state to watchdog
volatile char progr_state[128] = "Initializing\n";
void * state_sender() {
    char * fifoTtoW = "/tmp/fifoTtoW";
    while (1) {
        int fdW = open(fifoTtoW, O_WRONLY);
        write(fdW, (const void *)progr_state, sizeof(progr_state));
        close(fdW);
        usleep(500000);
    }
}

int main() {
    write_log("[INFO] Starting");
//Declare the variables
    //for the targets
    int Targets[2][9];
//Open the pipe
    //Creating pipe from Blackboard  to Targets
    char * fifoBtoT = "/tmp/fifoBtoT"; 
    //Creating pipe from Targets to Blackboard  
    char * fifoTtoB = "/tmp/fifoTtoB"; 

    int fd1 = open(fifoTtoB, O_WRONLY);
    int fd2 = open(fifoBtoT, O_RDONLY);

    if (fd1 < 0 || fd2 < 0) {
        write_log("[ERROR] Cant't open the pipes");
        perror("open fifo");
        exit(1);
    }
//Signal setup
    signal(SIGUSR1, handler);
//Thread setup
    pthread_t thread;
    pthread_create(&thread, NULL, state_sender, NULL);
//Main loop
    write_log("[INFO] Starting genrating targets");
    while (running) {
    //Generate new values
        snprintf((char *)progr_state, sizeof(progr_state),"Generating new target coordinates\n");
        for (int j = 0; j < 9; j++) {
            Targets[0][j]=random_int(1,99);
        }
        for (int j = 0; j < 9; j++) {
            Targets[1][j]=random_int(1,39);
        }
    //send the targets to blackboard
        snprintf((char *)progr_state, sizeof(progr_state),"Sending new targets to B\n");
        //ask to write
        write(fd1, "w", 1);

        //send the values of the tab when the blackboard is ready
        char buffer[128];
        int n = read(fd2, buffer, sizeof(buffer));
        if (n > 0 && strncmp(buffer, "ok", 2) == 0) {
            char buffer[1024];
            int pos = 0;

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 9; j++) {
                    pos += snprintf(buffer + pos, sizeof(buffer) - pos, "%d ", Targets[i][j]);
                }
            }
            buffer[pos++] = '\n';

            write(fd1, buffer, pos);
        }
    //
        snprintf((char *)progr_state, sizeof(progr_state),"Waiting\n");
        sleep(60); //wait 1 minute because it is impossible to reach all the target in less than 1 minute
    }
//Terminate programme
    write_log("[INFO] Terminating");
    snprintf((char *)progr_state, sizeof(progr_state),"Finishing program\n");
    close(fd1);
    close(fd2);
    pthread_detach(thread);
    return 0;
}
