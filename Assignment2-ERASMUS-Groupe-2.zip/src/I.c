#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <ncurses.h>
#include <signal.h>
#include <pthread.h>
#include <time.h>
#include <sys/time.h>
#include <sys/file.h>

void write_log(const char *message) {
//open without resetting the file
    FILE *log = fopen("log/logfile.txt", "a"); 
    if (!log) {
        perror("fopen");
        return;
    }
//lock
    int fd = fileno(log);
    if (flock(fd, LOCK_EX) != 0) { // wait for the file to be available
        perror("flock");
        fclose(log);
        return;
    }

// write
    // Create a time tag
    struct timeval tv;
    gettimeofday(&tv, NULL); //read seconds and microseconds
    struct tm* tm_info = localtime(&tv.tv_sec);//change seconds into hour/minut/second
    int millis = tv.tv_usec / 1000;//change microseconds into milliseconds
    //Create a string with all the numbers
    static char buffer[32];
    snprintf(buffer, sizeof(buffer),"%02d:%02d:%02d.%03d",tm_info->tm_hour,tm_info->tm_min,tm_info->tm_sec,millis);

    fprintf(log, "[%s] [I] %s\n", buffer, message);
//flush
    fflush(log);
// unlock
    flock(fd, LOCK_UN);
//close the file
    fclose(log);
}

//function to print keys
void draw_key(WINDOW *win, int y, int x, const char *label) {
    // corners
    mvwaddch(win, y,   x,   ACS_ULCORNER);
    mvwaddch(win, y,   x+4, ACS_URCORNER);
    mvwaddch(win, y+2, x,   ACS_LLCORNER);
    mvwaddch(win, y+2, x+4, ACS_LRCORNER);
    // horizontale lines
    mvwhline(win, y,   x+1, ACS_HLINE, 3);
    mvwhline(win, y+2, x+1, ACS_HLINE, 3);
    // verticale lines
    mvwvline(win, y+1, x,   ACS_VLINE, 1);
    mvwvline(win, y+1, x+4, ACS_VLINE, 1);
    // lettre
    mvwprintw(win, y+1, x+2, "%s", label);
}
//Signal handler
volatile sig_atomic_t running = 1;
void handler(int s) {
    running = 0;
}
//Thread for sending state to watchdog
volatile char progr_state[128] = "Initializing\n";
void * state_sender() {
    char * fifoItoW = "/tmp/fifoItoW";
    while (1) {
        int fdW = open(fifoItoW, O_WRONLY);
        write(fdW, (const void *)progr_state, sizeof(progr_state));
        close(fdW);
        usleep(500000);
    }
}

int main() {
    write_log("[INFO] Starting");
//Declare the variables
    //For keyboard
    char key = 's';
//openning the pipe
    //Creating pipe from Blackboard  to Input
    char * fifoBtoI = "/tmp/fifoBtoI"; 
    //Creating pipe from Input to Blackboard  
    char * fifoItoB = "/tmp/fifoItoB"; 
    //Creating pipe from Input to Init 
    char * fifoItoI = "/tmp/fifoItoI"; 

    int fd1 = open(fifoItoB, O_WRONLY);
    int fd2 = open(fifoBtoI, O_RDONLY);
    int fd3 = open(fifoItoI, O_WRONLY);

    if (fd1 < 0 || fd2 < 0 || fd3 < 0) {
        write_log("[ERROR] Cant't open the pipes");
        perror("open fifo");
        exit(1);
    }
// ncurses setup
    initscr();
    cbreak();
    noecho();
    keypad(stdscr, TRUE);
    WINDOW *win = newwin(20,21, 2, 0);
    nodelay(stdscr, TRUE);
    mvprintw(0,0,"Inputs : press S to start.");
//Signal setup
    signal(SIGUSR1, handler);
    //must block the other signals if the program is launched in konsole
    signal(SIGINT, handler);
    signal(SIGTERM, handler);
    signal(SIGHUP, handler);
//Thread setup
    pthread_t thread;
    pthread_create(&thread, NULL, state_sender, NULL);
//Main loop
    write_log("[INFO] Starting printing the scene");
    while (running) {
    //Read the key pressed
        snprintf((char *)progr_state, sizeof(progr_state),"Waiting for a key\n");
        char ch;
        //wait for a key pressed until running = 0
        while(running)  {
            ch = getch();
            if(ch!=ERR) {
                break;
            }
        }
        if ((ch=='a')||(ch=='z')||(ch=='q')||(ch=='s')||(ch=='d')||(ch=='x')||(ch=='e')) { // -> New part corrected
            key=ch;
        }
    //Print the informations on the screen
        snprintf((char *)progr_state, sizeof(progr_state),"Printing the screen\n");
        werase(win);
        box(win, 0, 0);

        //print the keyboard in win
        draw_key(win, 1, 1, "A"); draw_key(win, 1, 6, "Z"); draw_key(win, 1, 11, "E"); //-> New part corrected
        draw_key(win, 4, 3, "Q"); draw_key(win, 4, 8, "S"); draw_key(win, 4, 13, "D");
        draw_key(win, 7, 10, "X");
        //Informations abour the key's function
        mvwprintw(win, 9, 2,  "A : Exit");
        mvwprintw(win, 10, 2, "S : Brake");
        mvwprintw(win, 11, 2, "E : Neutral"); // -> New part corrected
        mvwprintw(win, 12, 2, "Z : Up");
        mvwprintw(win, 13, 2, "Q : Left");
        mvwprintw(win, 14, 2, "D : Right");
        mvwprintw(win, 15, 2, "X : Down");
        //Print the key pressed
        mvwprintw(win, 17, 2, "Pressed key : %c", key);

        wrefresh(win);
    //Transmit the key to the blackboard
        if(running) { //do not try to communicate ones the program is suppose to finish
            snprintf((char *)progr_state, sizeof(progr_state),"Sending the key to B\n");
            //ask to write
            write(fd1, "w", 1);
            
            //send the values when the blackboard is ready
            char buffer[128];
            int n = read(fd2, buffer, sizeof(buffer));
            if (n > 0 && strncmp(buffer, "ok", 2) == 0) {
                char msg[128];
                snprintf(msg, sizeof(msg), "%c\n", key);
                write(fd1, msg, strlen(msg));
            }
    //Case key = 'a' -> send message to master to close everything
            if(key=='a')
            {
                snprintf((char *)progr_state, sizeof(progr_state),"Telling Init the program must terminate\n");
                write(fd3,"STOP",4);
            }
        }
    //
    }
//Terminate programme
    write_log("[INFO] Terminating");
    snprintf((char *)progr_state, sizeof(progr_state),"Finishing program\n");
    close(fd1);
    close(fd2);
    close(fd3);
    delwin(win);
    endwin();
    pthread_detach(thread);
    return 0;
//
}
