#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <signal.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <sys/file.h>

void write_log(const char *message) {
//open without resetting the file
    FILE *log = fopen("log/logfile.txt", "a"); 
    if (!log) {
        perror("fopen");
        return;
    }
//lock
    int fd = fileno(log);
    if (flock(fd, LOCK_EX) != 0) { // wait for the file to be available
        perror("flock");
        fclose(log);
        return;
    }

// write
    // Create a time tag
    struct timeval tv;
    gettimeofday(&tv, NULL); //read seconds and microseconds
    struct tm* tm_info = localtime(&tv.tv_sec);//change seconds into hour/minut/second
    int millis = tv.tv_usec / 1000;//change microseconds into milliseconds
    //Create a string with all the numbers
    static char buffer[32];
    snprintf(buffer, sizeof(buffer),"%02d:%02d:%02d.%03d",tm_info->tm_hour,tm_info->tm_min,tm_info->tm_sec,millis);

    fprintf(log, "[%s] [Init] %s\n", buffer, message);
//flush
    fflush(log);
// unlock
    flock(fd, LOCK_UN);
//close the file
    fclose(log);
}

int main() {
//Reset the logfile
    FILE *fl = fopen("log/logfile.txt", "w"); //Replace the past values
    if (fl == NULL) {
        perror("logfile.txt not open");
        return EXIT_FAILURE;
    }
    fprintf(fl,"----------------NEW PROGRAM-------------------\n");
    fflush(fl);
    fclose(fl);
    write_log("[INFO] Starting");
//Creating pipes
    //Creating fifo for the blackboard communication-------------
    //Creating pipe from Blackboard  to Drone
    char * fifoBtoD = "/tmp/fifoBtoD"; 
    mkfifo(fifoBtoD, 0666);
    //Creating pipe from Drone to Blackboard  
    char * fifoDtoB = "/tmp/fifoDtoB"; 
    mkfifo(fifoDtoB, 0666);
    //Creating pipe from Blackboard  to Input
    char * fifoBtoI = "/tmp/fifoBtoI"; 
    mkfifo(fifoBtoI, 0666);
    //Creating pipe from Input to Blackboard  
    char * fifoItoB = "/tmp/fifoItoB"; 
    mkfifo(fifoItoB, 0666);
    //Creating pipe from Blackboard  to Obstacles
    char * fifoBtoO = "/tmp/fifoBtoO"; 
    mkfifo(fifoBtoO, 0666);
    //Creating pipe from Obstacles to Blackboard  
    char * fifoOtoB = "/tmp/fifoOtoB"; 
    mkfifo(fifoOtoB, 0666);
    //Creating pipe from Blackboard  to Targets
    char * fifoBtoT = "/tmp/fifoBtoT"; 
    mkfifo(fifoBtoT, 0666);
    //Creating pipe from Targets to Blackboard  
    char * fifoTtoB = "/tmp/fifoTtoB"; 
    mkfifo(fifoTtoB, 0666);
    //Creating fifo for the "exit" function---------------------
    //Crerating pipe from Input to Init
    char * fifoItoI = "/tmp/fifoItoI"; 
    mkfifo(fifoItoI, 0666);
    //Creating fifo for the watchdog----------------------------
    //Creating pipe from Blackboard to WAtchdog
    char * fifoBtoW = "/tmp/fifoBtoW";
    mkfifo(fifoBtoW, 0666);
    //Creating pipe from Drone to WAtchdog
    char * fifoDtoW = "/tmp/fifoDtoW";
    mkfifo(fifoDtoW, 0666);
    //Creating pipe from Input to WAtchdog
    char * fifoItoW = "/tmp/fifoItoW";
    mkfifo(fifoItoW, 0666);
    //Creating pipe from Obstacles to WAtchdog
    char * fifoOtoW = "/tmp/fifoOtoW";
    mkfifo(fifoOtoW, 0666);
    //Creating pipe from Targets to WAtchdog
    char * fifoTtoW = "/tmp/fifoTtoW";
    mkfifo(fifoTtoW, 0666);

//Open a file to store the PID
    FILE *fp = fopen("log/pid.txt", "w"); //Replace the past values
    if (fp == NULL) {
        write_log("[ERROR] Can't open pid.txt");
        perror("pid.txt not open");
        return EXIT_FAILURE;
    }
    write_log("[INFO] Creating new file pid.txt");
    fprintf(fp, "Master process : %d\n",getpid());

//Fork+exec to launch the programmes and write the pid in the file
    write_log("[INFO] Starting to launch the programs");

    pid_t pid;
    pid_t list_pid[6];

    // Open B in konsole
    pid = fork();
    if (pid < 0) { perror("fork B"); exit(EXIT_FAILURE); }
    if (pid == 0) {
        execlp("konsole", "konsole", "-e", "./bin/B", NULL);
        write_log("[ERROR] exec B failed");
        perror("exec B");
        exit(EXIT_FAILURE);
    }
    else
    {
        printf("[B] Start with pid %d\n", pid);
        fprintf(fp, "Blackboard : %d\n",pid);
        list_pid[0]=pid;
    }

    // Open D
    pid = fork();
    if (pid < 0) { perror("fork D"); exit(EXIT_FAILURE); }
    if (pid == 0) {
        execlp("./bin/D", "D", NULL);
        write_log("[ERROR] exec D failed");
        perror("exec D");
        exit(EXIT_FAILURE);
    }
    else
    {
        printf("[D] Start with pid %d\n", pid);
        fprintf(fp, "Drone : %d\n",pid);
        list_pid[1]=pid;
    }

    // Open I in konsole
    pid = fork();
    if (pid < 0) { perror("fork I"); exit(EXIT_FAILURE); }
    if (pid == 0) {
        execlp("konsole", "konsole", "-e", "./bin/I", NULL);
        write_log("[ERROR] exec I failed");
        perror("exec I");
        exit(EXIT_FAILURE);
    }
    else
    {
        printf("[I] Start with pid %d\n", pid);
        fprintf(fp, "Inputs : %d\n",pid);
        list_pid[2]=pid;
    }

    // Open O
    pid = fork();
    if (pid < 0) { perror("fork O"); exit(EXIT_FAILURE); }
    if (pid == 0) {
        execlp("./bin/O", "O", NULL);
        write_log("[ERROR] exec O failed");
        perror("exec O");
        exit(EXIT_FAILURE);
    }
    else
    {
        printf("[O] Start with pid %d\n", pid);
        fprintf(fp, "Obstacles : %d\n",pid);
        list_pid[3]=pid;
    }

    // Open T
    pid = fork();
    if (pid < 0) { perror("fork T"); exit(EXIT_FAILURE); }
    if (pid == 0) {
        execlp("./bin/T", "T", NULL);
        write_log("[ERROR] exec T failed");
        perror("exec T");
        exit(EXIT_FAILURE);
    }
    else
    {
        printf("[T] Start with pid %d\n", pid);
        fprintf(fp, "Targets : %d\n",pid);
        list_pid[4]=pid;
    }

    // Open W in konsole
    pid = fork();
    if (pid < 0) { perror("fork W"); exit(EXIT_FAILURE); }
    if (pid == 0) {
        execlp("konsole", "konsole", "-e", "./bin/W", NULL);
        write_log("[ERROR] exec W failed");
        perror("exec W");
        exit(EXIT_FAILURE);
    }
    else
    {
        printf("[W] Start with pid %d\n", pid);
        fprintf(fp, "Watchdog : %d\n",pid);
        list_pid[5]=pid;
    }

//Close the file once every program have been launched
    write_log("[INFO] All the pid have been written");
    if (fclose(fp) != 0) {
        perror("pid.txt not closed");
        return EXIT_FAILURE;
    }

//Wait for STOP message
    //Open fifo to get the "STOP" message from Input
    int fd = open(fifoItoI, O_RDONLY);
    if (fd < 0) {
        write_log("[ERROR] Can't open fifoItoI");
        perror("open fifo");
        exit(1);
    }
    //Read the fifo
    char buf[32] = {0};
    while(1){ //block until received a read message (a not if the pipe is closed)
        int a = read(fd, buf, sizeof(buf));
        if(a!=0) break;
    }
    close(fd);
    write_log("[INFO] Exit message received");
    write_log("[INFO] Killing everyone");
    // Send SIGUSR1 to everyone
    printf("[Init] Kill everyone\n");
    for (int i = 0; i < 6; i++) {
        kill(list_pid[i], SIGUSR1);
    }

//Waiting for the programs to finish
    while (wait(NULL) > 0);
    write_log("[INFO] All process have finished");
    printf("Everyone finished.\n");

    write_log("[INFO] Terminating");
    //Unlink every pipe
    unlink(fifoBtoD); 
    unlink(fifoDtoB); 
    unlink(fifoBtoI);
    unlink(fifoItoB);
    unlink(fifoBtoO); 
    unlink(fifoOtoB);
    unlink(fifoBtoT); 
    unlink(fifoTtoB);
    unlink(fifoItoI);
    unlink(fifoBtoW);
    unlink(fifoDtoW);
    unlink(fifoItoW);
    unlink(fifoOtoW);
    unlink(fifoTtoW);

    return 0;
}
